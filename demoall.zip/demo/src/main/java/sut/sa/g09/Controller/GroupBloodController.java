package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.GroupBlood;
import sut.sa.g09.Repository.GroupBloodRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
public class GroupBloodController {
    @Autowired private GroupBloodRepository groupbloodRepository;


    @GetMapping(path = "/groupblood")
    private Collection<GroupBlood> getGroupBloodCollection() {
        return this.groupbloodRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/groupblood/{id}")
    private GroupBloodRepository getGroupBloodById(@PathVariable Long id){
        return (GroupBloodRepository) this.groupbloodRepository.findById(id).get();
    }

    @PutMapping(path = "/groupblood/{id}")
    private GroupBlood replaceBloodType(@RequestBody GroupBlood newGroupBlood, @PathVariable Long id){
        return groupbloodRepository.findById(id).map(groupblood -> {
            groupblood.setGroupblood(newGroupBlood.getGroupblood());
            return groupbloodRepository.save(groupblood);
        }).orElseGet(() -> {
            newGroupBlood.setID(id);
            return groupbloodRepository.save(newGroupBlood);
        });
    }

    @PostMapping(path = "/groupBlood")
    private GroupBlood newGroupBlood(@RequestBody GroupBlood newGroupBlood){
        return groupbloodRepository.save(newGroupBlood);
    }

    @DeleteMapping(path = "/groupBlood/{id}")
    private void deleteAById(@PathVariable Long id){
        groupbloodRepository.deleteById(id);
    }

}