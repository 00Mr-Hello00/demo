package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import sut.sa.g09.Entity.Allergic_Patient;
import sut.sa.g09.Repository.Allergic_PatientRepository;
import sut.sa.g09.Repository.BeAllergicRepository;
import sut.sa.g09.Repository.PatientRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
public class Allergic_PatientController {
    @Autowired private Allergic_PatientRepository allergic_patientRepository;
    @Autowired private BeAllergicRepository beallergicRepository;
    @Autowired private PatientRepository patientRepository;

    @GetMapping(path = "/allergic_patient")
    private Collection<Allergic_Patient> getallergic_patientCollection(){
        return this.allergic_patientRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/allergic_patient/{id}")
    private Allergic_PatientRepository getallergic_patientById(@PathVariable Long id){
        return (Allergic_PatientRepository) this.allergic_patientRepository.findById(id).get();
    }
}


