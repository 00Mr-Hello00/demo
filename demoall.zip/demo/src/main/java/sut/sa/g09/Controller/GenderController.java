package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.Gender;
import sut.sa.g09.Repository.GenderRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
public class GenderController {
    @Autowired private GenderRepository genderRepository;

    @GetMapping(path = "/gender")
    private Collection<Gender> getGenderCollection(){
        return this.genderRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/gender/{id}")
    private GenderRepository getGenderById(@PathVariable Long id){
        return (GenderRepository) this.genderRepository.findById(id).get();
    }

    @PutMapping(path = "/gender/{id}")
    private Gender replaceGender(@RequestBody Gender newGender, @PathVariable Long id){
        return genderRepository.findById(id).map(gender -> {
            gender.setSex(newGender.getSex());
            return genderRepository.save(gender);
        }).orElseGet(() -> {
            newGender.setID(id);
            return genderRepository.save(newGender);
        });
    }

    @PostMapping(path = "/gender")
    private Gender newGender(@RequestBody Gender newGender){
        return genderRepository.save(newGender);
    }

    @DeleteMapping(path = "/gender/{id}")
    private void deleteAById(@PathVariable Long id){
        genderRepository.deleteById(id);
    }
}

