package sut.sa.g09.Entity;

import lombok.NonNull;

import javax.persistence.*;

@Entity
@Table(name="Doctor")
public class Doctor {
    @Id
    @SequenceGenerator(name="Doctor_seq",sequenceName="Doctor_seq")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="Doctor_seq")
    @Column(name ="Doc_id",unique = true, nullable = true)
    private @NonNull Long docid;
    private @NonNull String affiliation;
    private @NonNull String  docname;
    private @NonNull String pass;
    private @NonNull String doctorid;
    private @NonNull Integer tel;

    public Doctor(){}

    public Doctor(String affiliation, String docname, String pass, String doctorid, Integer tel) {
        this.affiliation = affiliation;
        this.docname = docname;
        this.pass = pass;
        this.doctorid = doctorid;
        this.tel = tel;
    }

    public Long getDocid() {
        return docid;
    }

    public void setDocid(Long docid) {
        this.docid = docid;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public void setAffiliation(String affiliation) {
        this.affiliation = affiliation;
    }

    public String getDocname() {
        return docname;
    }

    public void setDocname(String docname) {
        this.docname = docname;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(String doctorid) {
        this.doctorid = doctorid;
    }

    public Integer getTel() {
        return tel;
    }

    public void setTel(Integer tel) {
        this.tel = tel;
    }
}
