package sut.sa.g09.Entity;

import lombok.NonNull;

import javax.persistence.*;

@Entity
@Table(name="Disease")
public class Disease {
    @Id
    @SequenceGenerator(name="Disease_seq",sequenceName="Disease_seq")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="Disease_seq")
    @Column(name ="Dis_id",unique = true, nullable = true)
    private @NonNull Long disid;
    private @NonNull String disname;
    private @NonNull String aboutdis;


    @ManyToOne(fetch = FetchType.EAGER, targetEntity = DiseaseType.class)
    @JoinColumn( name ="Type_id", insertable = true)
    private DiseaseType dis;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = AgeRange.class)
    @JoinColumn( name ="Age_id", insertable = true)
    private AgeRange age;


    public Disease(String disname, String aboutdis, DiseaseType dis,AgeRange age) {
        this.disname = disname;
        this.aboutdis = aboutdis;
        this.dis = dis;
        this.age = age;
    }

    public Disease(){}


    public AgeRange getAge() {
        return age;
    }

    public void setAge(AgeRange age) {
        this.age = age;
    }

    public DiseaseType getDis() {
        return dis;
    }

    public void setDis(DiseaseType dis) {
        this.dis = dis;
    }

    public Long getDisid() {
        return disid;
    }

    public void setDisid(Long disid) {
        this.disid = disid;
    }

    public String getDisname() {
        return disname;
    }

    public void setDisname(String disname) {
        this.disname = disname;
    }

    public String getAboutdis() {
        return aboutdis;
    }

    public void setAboutdis(String aboutdis) {
        this.aboutdis = aboutdis;
    }
}
