package sut.sa.g09.Entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
@Table(name = "Healtcheck")
public class Healtcheck {

    @Id
    @SequenceGenerator(name="healtcheck_seq",sequenceName="healtcheck_seq")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="healtcheck_seq")
    @Column(name = "Healtcheck_Id")
    private @NonNull Long heid;
    private @NonNull int height;
    private @NonNull int weight;
    private @NonNull int bmi;
    private @NonNull int pressure;
    private @NonNull String tooth;
    private @NonNull int eye;
    private @NonNull String hear;
    private @NonNull String lung;
    private @NonNull String bloodsugar;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Patient.class)
    @JoinColumn(name = "Patient_Id",insertable = true)
    private Patient p;

}

