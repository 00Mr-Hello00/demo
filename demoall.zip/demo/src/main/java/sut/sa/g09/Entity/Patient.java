package sut.sa.g09.Entity;

import javax.persistence.Entity;
import javax.persistence.*;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@Table(name = "Patient")
public class Patient {

    @Id
    @GeneratedValue
    @Column(name = "Patient_ID")
    private @NonNull Long ID;
    private @NonNull int idp;
    private @NonNull String name;
    private @NonNull int age;
    private @NonNull String phone;
    private @NonNull String service;




    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Gender.class)
    @JoinColumn(name = "Gender_Id")
    private Gender gender;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = BloodType.class)
    @JoinColumn(name = "BloodType_Id")
    private BloodType bloodtype;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Allergic_Patient.class)
    @JoinColumn(name = "Allergic_Patient_ID")
    private Allergic_Patient allergic_patient;
}



