package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import sut.sa.g09.Entity.BloodType;
import sut.sa.g09.Repository.BloodTypeRepository;
import sut.sa.g09.Repository.GroupBloodRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
public class BloodTypeController {

    @Autowired private BloodTypeRepository bloodtypeRepository;
    @Autowired private GroupBloodRepository groupbloodRepository;

    @GetMapping(path = "/bloodtype")
    private Collection<BloodType> getBloodTypeCollection() {
        return this.bloodtypeRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/bloodtype/{id}")
    private BloodTypeRepository getBloodTypeById(@PathVariable Long id){
        return (BloodTypeRepository) this.bloodtypeRepository.findById(id).get();
    }
}
