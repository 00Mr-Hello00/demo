package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.BeAllergic;
import sut.sa.g09.Repository.BeAllergicRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
public class BeAllergicController {
    @Autowired
    private BeAllergicRepository beallergicRepository;

    @GetMapping(path = "/beallergic")
    private Collection<BeAllergic> getBeAllergicCollection() {
        return this.beallergicRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/beallergic/{id}")
    private BeAllergicRepository getBeAllergicById(@PathVariable Long id){
        return (BeAllergicRepository) this.beallergicRepository.findById(id).get();
    }

    @PutMapping(path = "/beallergic/{id}")
    private BeAllergic replaceBeAllerdic(@RequestBody BeAllergic newBeAllergic, @PathVariable Long id){
        return beallergicRepository.findById(id).map(beAllergic -> {
            beAllergic.setMedicine(newBeAllergic.getMedicine());
            return beallergicRepository.save(beAllergic);
        }).orElseGet(() -> {
            newBeAllergic.setID(id);
            return beallergicRepository.save(newBeAllergic);
        });
    }

    @PostMapping(path = "/beallergic")
    private BeAllergic newBeAllergic(@RequestBody BeAllergic newBeAllergic){
        return beallergicRepository.save(newBeAllergic);
    }

    @DeleteMapping(path = "/beallergic/{id}")
    private void deleteAById(@PathVariable Long id){
        beallergicRepository.deleteById(id);
    }
}
