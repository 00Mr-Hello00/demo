package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.Patient;
import sut.sa.g09.Repository.BloodTypeRepository;
import sut.sa.g09.Repository.GenderRepository;
import sut.sa.g09.Repository.PatientRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PatientController {
    @Autowired private PatientRepository patientRepository;
    @Autowired private GenderRepository genderRepository;
    @Autowired private BloodTypeRepository bloodtypeRepository;

    @GetMapping(path = "/patient")
    public Collection<Patient> getPatientsCollection(){
        return this.patientRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/patient/{id}")
    public Patient getPatientById(@PathVariable Long id){
        return this.patientRepository.findById(id).get();
    }

    @PutMapping(path = "/patient/{id}")
    public Patient replacePatient(@RequestBody Patient newPatient, @PathVariable Long id){
        return patientRepository.findById(id).map(patient -> {
            patient.setIdp(newPatient.getIdp());
            patient.setName(newPatient.getName());
            patient.setAge(newPatient.getAge());
            patient.setPhone(newPatient.getPhone());
            patient.setService(newPatient.getService());
            return patientRepository.save(patient);
        }).orElseGet(() -> {
            newPatient.setID(id);
            return patientRepository.save(newPatient);
        });
    }

    @PostMapping(path ="/patient")
    public Patient newPatient(@RequestBody Patient newPatient){
        return patientRepository.save(newPatient);
    }

    @DeleteMapping(path = "/patient/{id}")
    public void deleteAById(@PathVariable Long id){
        patientRepository.deleteById(id);
    }
}