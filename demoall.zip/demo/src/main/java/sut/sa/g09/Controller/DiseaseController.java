package sut.sa.g09.Controller;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.AgeRange;
import sut.sa.g09.Entity.Disease;
import sut.sa.g09.Entity.DiseaseType;
import sut.sa.g09.Entity.Doctor;
import sut.sa.g09.Repository.AgeRangeRepository;
import sut.sa.g09.Repository.DiseaseRepository;
import sut.sa.g09.Repository.DiseaseTypeRepository;
import sut.sa.g09.Repository.DoctorRepository;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class DiseaseController {
    @Autowired
    private DiseaseRepository diseaseRepository ;
    @Autowired
    private DiseaseTypeRepository diseaseTypeRepository;
    @Autowired
    private AgeRangeRepository ageRangeRepository;
    @Autowired
    private DoctorRepository doctorRepository;
   //----------------------Disease-------------------------------------//
    @GetMapping("/disease")
    public Collection<Disease> disease(){
        return  diseaseRepository.findAll().stream().collect(Collectors.toList()); }
    @GetMapping("/disease/{disid}")
    public Optional<Disease> takeinDiseaseByid(@PathVariable Long disid){
      return diseaseRepository.findById(disid); }

    @PostMapping("/disease/{typeid}/{ageid}")
    public Disease createDis(@PathVariable Long typeid,@PathVariable Long ageid, @RequestBody String dataDis)throws JsonParseException, IOException {
        final String decoded = URLDecoder.decode(dataDis,"UTF-8");
        dataDis = decoded;
        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = mapper.readTree(dataDis);
           JsonNode jsonDisName = actualObj.get("inputDisName");
           JsonNode jsonAboutDis = actualObj.get("inputAboutDis");

           Disease ds = new Disease();
           ds.setDisname(jsonDisName.textValue());
           ds.setAboutdis(jsonAboutDis.textValue());
           ds.setDis(diseaseTypeRepository.getOne(typeid));
           ds.setAge(ageRangeRepository.getOne(ageid));
           return diseaseRepository.save(ds);
    }


     //---------------------------DiseaseType------------------------------------//
    @GetMapping("/diseasetype")
    public  Collection<DiseaseType> diseaseType(){
        return diseaseTypeRepository.findAll().stream().collect(Collectors.toList()); }
    @GetMapping("/diseasetype/{typeid}")
    public Optional<DiseaseType> takeinDiseaseTypeByid(@PathVariable Long typeid){
        return diseaseTypeRepository.findById(typeid);
    }
    //----------------------------AgeRange--------------------------------------//
    @GetMapping("/agerange")
    public Collection<AgeRange>  ageRanges(){
        return ageRangeRepository.findAll().stream().collect(Collectors.toList()); }
    @GetMapping("/agerange/{ageid}")
    public Optional<AgeRange> takeinAgeRangeByid(@PathVariable Long ageid){
        return ageRangeRepository.findById(ageid);
    }
    //---------------------------Doctor-----------------------------------------//
    @GetMapping("/doctor")
    public Collection<Doctor> doctors(){
     return     doctorRepository.findAll().stream().collect(Collectors.toList()); }
    @GetMapping("/doctor/{docid}")
    public Optional<Doctor> takeinDoctorByid(@PathVariable Long docid){
        return doctorRepository.findById(docid);
    }
    @PostMapping("/doctor{docid}")
    public Doctor createDoc(@PathVariable Long docid,@RequestBody String dataDoc)throws  JsonParseException, IOException {
        final String decoded = URLDecoder.decode(dataDoc,"UTF-8");
        dataDoc = decoded;
        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = mapper.readTree(dataDoc);

        JsonNode jsonAffiliation = actualObj.get("inputAffiliation");
        JsonNode jsonDocname  = actualObj.get("inputDocname");
        JsonNode jsonPass     = actualObj.get("inputPass");
        JsonNode jsonDoctorid = actualObj.get("inputDoctorid");
        JsonNode jsonTel      = actualObj.get("inputTel");

        Doctor dr = new Doctor();
        dr.setAffiliation(jsonAffiliation.textValue());
        dr.setDocname(jsonDocname.textValue());
        dr.setPass(jsonPass.textValue());
        dr.setDoctorid(jsonDoctorid.textValue());
        dr.setTel(jsonTel.intValue());
        return doctorRepository.save(dr);
    }

    }


