package sut.sa.g09.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.*;
import javax.persistence.*;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@Table(name = "Allergic_Patient")
public class Allergic_Patient {

    @Id
    @GeneratedValue
    @Column(name = "Allergic_Patient_ID")
    private @NonNull Long allergic_patient_id;
    private @NonNull Long allergic_id;


    @ManyToOne
    private BeAllergic beallergic;

}
