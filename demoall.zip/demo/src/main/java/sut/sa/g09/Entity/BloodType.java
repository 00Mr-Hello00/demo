package sut.sa.g09.Entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@Table(name = "BloodType")
public class BloodType {

    @Id
    @GeneratedValue
    @Column(name = "BloodType_ID")
    private @NonNull Long ID;

    @ManyToOne
    @JoinColumn(name = "Groupblood_ID")
    private GroupBlood groupblood;
}
