package sut.sa.g09.Entity;


import lombok.*;

import javax.persistence.*;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@Table(name = "GroupBlood")
public class GroupBlood {

    @Id
    @GeneratedValue
    @Column(name = "GroupBlood_ID")
    private @NonNull Long ID;
    private @NonNull String groupblood;
}
