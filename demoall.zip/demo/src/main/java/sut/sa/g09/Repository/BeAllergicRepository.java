package sut.sa.g09.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.webmvc.RepositoryRestController;
import sut.sa.g09.Entity.BeAllergic;


@RepositoryRestController

public interface BeAllergicRepository extends  JpaRepository <BeAllergic, Long>{
}
