package sut.sa.g09.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.webmvc.RepositoryRestController;
import sut.sa.g09.Entity.Allergic_Patient;


@RepositoryRestController

public interface Allergic_PatientRepository extends  JpaRepository<Allergic_Patient,Long>{
}
