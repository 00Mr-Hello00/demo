package sut.sa.g09.Entity;

import lombok.NonNull;

import javax.persistence.*;

@Entity
@Table(name="DiseaseType")
public class DiseaseType {
    @Id
    @SequenceGenerator(name="DiseaseType_seq",sequenceName="DiseaseType_seq")
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator="DiseaseType_seq")
    @Column(name= "Type_id",unique = true, nullable = true)
    private @NonNull Long typeid;
    private @NonNull String distype;

    public  DiseaseType(){}

    public DiseaseType(String distype) {

        this.distype = distype;
    }

    public Long getTypeid() {
        return typeid;
    }

    public void setTypeid(Long typeid) {
        this.typeid = typeid;
    }

    public String getDistype() {
        return distype;
    }

    public void setDistype(String distype) {
        this.distype = distype;
    }
}
