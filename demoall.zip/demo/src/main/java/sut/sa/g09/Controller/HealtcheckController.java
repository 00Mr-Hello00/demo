package sut.sa.g09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sut.sa.g09.Entity.Healtcheck;
import sut.sa.g09.Repository.HealtcheckRepository;
import sut.sa.g09.Repository.ResultRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class HealtcheckController {
    @Autowired private HealtcheckRepository healtcheckRepository;
    @Autowired private ResultRepository resultRepository;

    @Autowired
    HealtcheckController(HealtcheckRepository healtcheckRepository) {
        this.healtcheckRepository = healtcheckRepository;
    }

    @GetMapping(path = "/healtcheck")
    private Collection<Healtcheck> getHealtcheckCollection(){
        return this.healtcheckRepository.findAll().stream().collect(Collectors.toList());
    }

    @GetMapping(path = "/patient/{heid}")
    private HealtcheckRepository getHealtcheckById(@PathVariable Long heid){
        return (HealtcheckRepository) this.healtcheckRepository.findById(heid).get();
    }

    @PutMapping(path = "/healtcheck/{heid}")
    private Healtcheck replaceHealtcheck(@RequestBody Healtcheck newHealtcheck, @PathVariable Long heid){
        return healtcheckRepository.findById(heid).map(healtcheck -> {
            healtcheck.setBloodsugar(newHealtcheck.getBloodsugar());
            healtcheck.setBmi(newHealtcheck.getBmi());
            healtcheck.setEye(newHealtcheck.getEye());
            healtcheck.setHear(newHealtcheck.getHear());
            healtcheck.setHeight(newHealtcheck.getHeight());
            healtcheck.setLung(newHealtcheck.getLung());
            healtcheck.setPressure(newHealtcheck.getPressure());
            healtcheck.setTooth(newHealtcheck.getTooth());
            healtcheck.setWeight(newHealtcheck.getWeight());
            return healtcheckRepository.save(healtcheck);
        }).orElseGet(() ->{
            newHealtcheck.setHeid(heid);
            return healtcheckRepository.save(newHealtcheck);
        });
    }

    @PostMapping(path = "/healtcheck")
    private Healtcheck newhealtcheck(@RequestBody Healtcheck newHealtcheck){
        return healtcheckRepository.save(newHealtcheck);
    }

}

