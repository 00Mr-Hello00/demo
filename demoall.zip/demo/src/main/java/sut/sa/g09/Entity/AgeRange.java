package sut.sa.g09.Entity;

import lombok.NonNull;

import javax.persistence.*;

@Entity
@Table(name ="AgeRange")
public class AgeRange {
    @Id
    @SequenceGenerator(name="AgeRange_seq",sequenceName="AgeRange_seq")
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator="AgeRange_seq")
    @Column(name = "Age_id")
    private @NonNull Long ageid;
    private @NonNull String  range;

    public AgeRange(){}

    public AgeRange(String range) {
        this.range = range;
    }

    public Long getAgeid() {
        return ageid;
    }

    public void setAgeid(Long ageid) {
        this.ageid = ageid;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }
}