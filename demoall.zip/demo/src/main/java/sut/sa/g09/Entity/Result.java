package sut.sa.g09.Entity;

import lombok.*;

import javax.persistence.*;


@Entity
@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
@Table(name = "Result")
public class Result {

    @Id
    @SequenceGenerator(name="result_seq",sequenceName="result_seq")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="result_seq")
    @Column(name = "Result_Id")
    private @NonNull Long Id;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Healtcheck.class)
    @JoinColumn(name = "Healtcheck_Id",insertable = true)
    private Healtcheck h;

    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Record.class)
    @JoinColumn(name = "Record_ID",insertable = true)
    private Record record;
}


