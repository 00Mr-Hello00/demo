package sut.sa.g09.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.webmvc.RepositoryRestController;
import sut.sa.g09.Entity.AgeRange;

import java.util.Optional;

@RepositoryRestController
public interface AgeRangeRepository extends JpaRepository<AgeRange,Long> {
    Optional<AgeRange>findById(Long ageid);
}
